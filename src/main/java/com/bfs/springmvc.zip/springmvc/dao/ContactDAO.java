package com.bfs.springmvc.dao;

import com.bfs.springmvc.domain.Contact;

import java.util.List;

public interface ContactDAO {



    List<Contact> getAllContact();
}
