package com.bfs.springmvc.service;

import com.bfs.springmvc.domain.Contact;

import java.util.List;

public interface ContactService {

    List<Contact> getAllContact();
}
