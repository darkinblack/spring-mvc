package com.bfs.springmvc.Constant;

public interface Constant {
    final String JWT_TOKEN_COOKIE_NAME = "JWT-TOKEN";
    final String SIGNING_KEY = "HappyJuneBatch";
}
